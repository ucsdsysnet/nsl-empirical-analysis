﻿Tumblr DMCA_Requests_Jan-Jun_2023.csv


This file contains details on DMCA complaints for January through June. See https://transparency.automattic.com/tumblr/copyright-and-trademark/




Tumblr_Gov_Info_Requests_Jan-Jun_2023.csv 


This file contains details on Government Information Requests for January through June 2023. See https://transparency.automattic.com/tumblr/copyright-and-trademark/




Tumblr_Gov_Removal_Requests_Jan-Jun_2023.csv


This file contains details on Government Removal Requests for January through June 2023. See https://transparency.automattic.com/tumblr/government-takedown-demands/




Tumblr_Trademark_Requests_Jan-Jun_2023.csv 


This file contains details on Trademark complaints for January through June 2023. See https://transparency.automattic.com/tumblr/copyright-and-trademark/