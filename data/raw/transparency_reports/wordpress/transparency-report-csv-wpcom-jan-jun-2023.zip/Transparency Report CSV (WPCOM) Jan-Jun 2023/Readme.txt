﻿WPCOM DMCA_Requests_Jan-Jun_2023.csv


This file contains details on DMCA complaints for January through June 2023.


See https://transparency.automattic.com/intellectual-property/ for more information on Trademark and DMCA reports.




WPCOM_Gov_Info_Requests_Jan-Jun_2023.csv


This file contains details on Government Information Requests for January through June 2023. See https://transparency.automattic.com/information-requests/ for more information.




WPCOM_Gov_Removal_Requests_Jan-Jun_2023.csv


This file contains details on Government Removal Requests for January through June 2023. See https://transparency.automattic.com/takedown-demands/ for more information.


WPCOM_IRU_Reports_Jan-Jun_2023.csv


This file contains details IRU requests for January through June 2023. See https://transparency.automattic.com/iru-reports/ for more information.




WPCOM_Trademark_Reports_Jan-Jun_2023.csv


This file contains details on Trademark complaints for January through June 2023.


See https://transparency.automattic.com/intellectual-property/ for more information on Trademark and DMCA reports.